/*
Name:           App Landing
Written by:     Okler Themes - (http://www.okler.net)
Theme Version:  9.9.0
*/

(function( $ ) {
	
	'use strict';

	

}).apply( this, [ jQuery ]);
